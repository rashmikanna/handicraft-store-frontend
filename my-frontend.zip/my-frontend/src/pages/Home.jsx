import Navbar from "../components/Navbar";
import Banner from "../components/Banner";
import CategoryList from "../components/CategoryList";
import { useEffect, useState } from "react";
import axios from "../axios";

const Home = () => {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    axios.get("categories/")
      .then(response => setCategories(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <div>
      <Navbar />
      <Banner />
      <div className="categories">
        {categories.map(category => (
          <CategoryList key={category.id} category={category} />
        ))}
      </div>
    </div>
  );
};

export default Home;
