const Banner = () => {
    return (
      <div className="banner">
        <img src="https://icdn.isrgrajan.com/in/2018/01/Kinnal-Toys-696x399.jpg
" alt="Handicrafts Banner" />
      </div>
    );
  };
  
  export default Banner;
  