import { Link } from "react-router-dom";

const CategoryList = ({ category }) => {
  return (
    <div className="category-card">
      <img src={category.image_url} alt={category.name} />
      <Link to={`/products?category=${category.name}`}>{category.name}</Link>
    </div>
  );
};

export default CategoryList;
