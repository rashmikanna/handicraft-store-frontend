import { Link } from "react-router-dom";
import "./Navbar.css";

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="logo">
        <Link to="/">eShop</Link>
      </div>
      <div className="search">
        <input type="text" placeholder="Search..." />
      </div>
      <div className="cart">
        <Link to="/cart">Cart</Link>
      </div>
    </nav>
  );
};

export default Navbar;
