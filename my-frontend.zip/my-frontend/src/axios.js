import axios from "axios";

// Set up Axios instance with your backend base URL
const instance = axios.create({
  baseURL: "http://localhost:8000/api/",  // Replace this with the base URL of your Django API
});

export default instance;
